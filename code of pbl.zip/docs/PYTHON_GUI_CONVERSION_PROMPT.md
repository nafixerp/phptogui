# GoldApp → Python Desktop GUI — Conversion Prompt (entry command)

Paste the prompt block below into an AI coding agent (Claude Code, etc.) **from the
repo root** `f:\sql9win64\goldapp`. It is the single entry instruction that kicks off
the whole Laravel-to-Python conversion, module by module, against the same MySQL DB.

---

## ⛒ THE PROMPT (copy everything between the lines)

```text
You are converting an existing Laravel 12 jewellery/gold-shop ERP into a native
Python DESKTOP GUI application, WITHOUT changing or migrating the database.

== SOURCE PROJECT ==
- Path: f:\sql9win64\goldapp
- Stack: Laravel 12, PHP 8.2, Blade views, MySQL (XAMPP)
- Scale: 220 controllers, 315 Blade views, 1071 routes, 33 migrations
- DB (from .env): driver mysql, host 127.0.0.1:3306, database "demo",
  secondary database "deom12", user root, empty password
- Domain: double-entry accounting + jewellery stock/weight (gold/silver/diamond),
  barcode, sales/purchase/orders/repairs/refinery, kuri schemes, goldsmith,
  staff payroll, GST/e-invoice/Tally compliance.
- Read these domain docs FIRST and treat them as the source of truth for rules:
  docs/accounting-posting-logic.md, docs/transaction-create-posting-logic.txt,
  docs/item-create-logic.txt, docs/customer-supplier-staff-create-logic.txt,
  docs/barcode-single-entry.md, docs/FULL_PROJECT_TREE.md

== TARGET ==
- Output folder: python_gui/  (create it; do not touch the Laravel app)
- GUI toolkit: customtkinter (Tkinter under the hood)
- DB access: SQLAlchemy Core + mysql-connector-python (raw SQL where the Laravel
  query is non-trivial — preserve exact column names and posting math)
- Config: read the existing Laravel .env (same DB credentials); do NOT hardcode
- Auth: reuse the legacy login tables (userm / userd / userhist) and the existing
  password hashing — replicate, do not reset existing users
- Reports/print: render with reportlab (PDF) to match the Blade print layouts
- Packaging target: PyInstaller one-folder build (Windows .exe)

== HARD RULES ==
1. The MySQL schema is FROZEN. No migrations, no renamed columns, no new tables
   unless I explicitly approve one. Both apps must run against the same DB during
   migration, so writes from Python must be byte-identical in effect to Laravel.
2. For every module, before writing Python: open the Laravel controller + its
   Blade view(s) + the routes + the tables it touches, and extract the exact
   queries, validation, and accounting/stock posting rules. Quote the source
   file:line you derived each rule from in a short comment.
3. Money and weight are decimals — never floats. Use Python Decimal everywhere,
   matching the DB column scale.
4. Each module = one Python window/frame + one service module (business rules) +
   one repository module (SQL). Keep UI, rules, and SQL separated.
5. After each module: run CRUD + the module's reports against the real "demo" DB
   and show me the before/after row counts and a sample posting to prove parity.
   Do not advance to the next module until I confirm.

== ARCHITECTURE TO CREATE (python_gui/) ==
  python_gui/
    main.py                 # app bootstrap, theme, login -> shell
    core/
      config.py             # parse ../.env
      db.py                 # engine/session factory, secondary-db handling
      auth.py               # legacy login (userm/userd) + permissions (Permission enum)
      decimals.py           # money/weight helpers
      pdf.py                # reportlab print-layout base
    ui/
      shell.py              # main window, sidebar nav, company selector
      widgets/              # reusable grid, date picker, party picker, amount field
    modules/
      <module>/
        view.py             # customtkinter frame
        service.py          # business rules ported from the controller
        repo.py             # SQL against frozen schema
    requirements.txt        # customtkinter, SQLAlchemy, mysql-connector-python,
                            # python-dotenv, reportlab, pyinstaller
    README.md               # how to run + per-module parity status table

== BUILD ORDER (do these phases in order; one module at a time within a phase) ==
  Phase 1  Shell: .env loader, DB connect, legacy login, dashboard, sidebar nav,
           company selection (CompanySelectController), application settings,
           user access / permissions.
  Phase 2  Masters: Item master, Item group/subgroup, Counter, Bill prefix,
           Denomination master, MC table, Stock type, Country/currency.
  Phase 3  Parties: Customer, Supplier, Phone book, opening balances/weights.
  Phase 4  Accounting core: Account master, Account ledger, Journal, Receipt,
           Payment, Cash book, Bank book, Day book — THIS is the riskiest;
           reproduce docs/accounting-posting-logic.md exactly.
  Phase 5  Sales: Sales bill, Sales return, Sales register, bill print/reprint.
  Phase 6  Purchase: Purchase bill, return, register, supplier reports.
  Phase 7  Inventory/Barcode: Stock register, verification, barcode entry/history.
  Phase 8  Orders: entry, update, rate-fix, pending reports, profit analysis.
  Phase 9  Schemes/Goldsmith/Staff: kuri, gold loan, smith book, staff payroll.
  Phase 10 Compliance/Integration: GST/GSTR, e-invoice, Tally export, WhatsApp.

== START NOW ==
Begin Phase 1 only. First produce:
  (a) a short module map for Phase 1 listing each Laravel controller/view/table
      involved, and
  (b) the python_gui/ scaffold with core/config.py, core/db.py, core/auth.py and a
      working login window that authenticates against the real demo DB.
Then stop and show me the login working before continuing.
```

---

## How to drive it after the first run

- Continue one module at a time: *"Proceed to the next Phase 1 module"* — never
  let it batch many modules; parity bugs in accounting are silent and expensive.
- For each module ask for the **parity proof**: same input → same ledger/stock rows
  as the Laravel app.
- Keep Laravel running in production until the Python side reaches parity for the
  modules you actually use. Both point at the same `demo` MySQL DB meanwhile.

## Notes / corrections vs. the older migration doc

- `python_gui/` does **not** exist yet (the old `PYTHON_GUI_MIGRATION.md` claimed a
  starter was completed — it isn't). This prompt creates it fresh.
- Real counts are **220 controllers / 1071 routes / 315 views** (old doc said
  201 / 883). The DB in `.env` is `demo` (secondary `deom12`).
```
