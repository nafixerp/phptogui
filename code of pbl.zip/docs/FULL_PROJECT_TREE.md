# GoldApp — Full Project Tree

Jewellery / Gold-shop ERP built on **Laravel 12 + PHP 8.2**, MySQL backend (XAMPP),
Blade server-rendered UI. Generated facts (this snapshot):

| Metric | Count |
|---|---|
| Controllers (`app/Http/Controllers/*.php`) | **220** |
| Eloquent models (`app/Models`) | 16 |
| Blade views (`resources/views/**`) | **315** |
| View module folders | ~115 |
| Route declarations (`routes/web.php`) | **1071** (1842 lines) |
| DB migrations | 33 |
| Config files | 11 |
| DB | MySQL `demo` (+ secondary `deom12`), driver `mysql` |

## Root layout (source only — vendor / zips / git backups omitted)

```text
goldapp/
├── app/
│   ├── Enums/
│   │   └── Permission.php
│   ├── Http/
│   │   ├── Controllers/         # 220 controllers (see modules below)
│   │   │   └── Concerns/
│   │   │       ├── HandlesSecondarySeriesPrefix.php
│   │   │       └── LogsDelpartAudit.php
│   │   ├── Middleware/
│   │   └── Requests/
│   ├── Models/                  # DenominationMaster, Item, ItemStock, MCTable,
│   │                            # PartyMCTable, PointCardTable, ProductModel,
│   │                            # Rotable, SalesBill, StockType, User, UserAccess,
│   │                            # UserM, UserPermission, GiftTable, ModelType
│   ├── Providers/
│   │   └── AppServiceProvider.php
│   ├── Services/
│   │   ├── PasswordService.php
│   │   └── WhatsAppService.php
│   └── Support/
│       ├── DatabaseBackupManager.php
│       ├── LegacyEInvoiceJsonService.php
│       ├── PrintLayout.php
│       └── SecondaryDatabaseSync.php
├── bootstrap/
├── config/                      # app, auth, cache, database, filesystems,
│                                # logging, mail, queue, services, session, stock
├── database/
│   ├── migrations/              # 33 migrations
│   ├── factories/
│   └── seeders/
├── public/                      # index.php, built assets
├── resources/
│   └── views/                   # 315 Blade views across ~115 module folders
├── routes/
│   ├── web.php                  # 1071 route declarations
│   └── console.php
├── storage/
├── tests/
├── assets/                      # logo.png, bg.mp4
├── docs/                        # this file + migration notes + logic docs
├── composer.json / composer.lock
├── package.json / vite.config.js
└── artisan
```

## Functional modules (controller + view groups)

### Authentication & shell
`NativeAuthController`, `NativeDashboardController`, `CompanySelectController`,
`ApplicationSettingsController`, `UserAccessController`, `BranchController`,
`AdministrationController`, `AdminController`, `BackupController`,
`IntegrityCheck(ing)Controller`.

### Masters
`ItemMasterController`, `ItemGroupController`, `ItemSubGroupController`,
`ItemPurityTypeController`, `ItemCatalogueController`, `ModelMasterController`,
`CountersController`, `CounterIssueController`, `BillPrefixController`,
`DenominationMasterController`, `MCTableController`, `PartyMCTableController`,
`StockTypeController`, `CountryCurrencyController`, `WastageTableController`,
`GiftTableController`, `ScaleController`, `HallmarkController`,
`PointCardController`.

### Parties
`NativeCustomerController`, `CustomerReportsController`, `CustomerOpBillsController`,
`CustomerBillwiseRcptController`, `CustomerCampaignController`,
`SupplierReportsController`, `SupplierBillwisePaymentController`,
`PhoneBookController`, `PartyCodeMergeController`, `PartyOpWeightController`.

### Sales
`SalesBillController`, `SalesBillConfirmationController`, `SalesBillPrintController`,
`SalesReturnController`, `SalesReturnPrintController`, `SalesRegisterController`,
`SalesReturnRegisterController`, `SalesBookReportController`,
`SalesCheckListController`, `MonthlySalesReportController`,
`NetSalesReportController`.

### Purchase
`PurchaseBillController`, `PurchaseBillConfirmationController`,
`PurchaseBillPrintController`, `PurchaseReturnController`,
`PurchaseRegisterController`, `PurchaseReturnRegisterController`,
`PurchaseBookController`, `PurchaseCheckListController`, `TaxPurchaseBookController`,
`DiamondPurchaseBillController`, `DiamondPurchaseReturnController`.

### Orders / Repairs / Refinery
`OrderBillController`, `OrderSaleController`, `OrderUpdateController`,
`OrderReprintController`, `OrderRateFixController`, `OrderBlockController`,
`OrderCancelController`, `OrderReturnsController`, `OrderProcessController`,
`OrderProfitAnalysisController`, `OrderPending*Controller`, `OrderAdvance*Controller`,
`RepairComplaintsController`, `RepairReceiptMemoPartyController`,
`RepairReturnController`, `RefineryBillController`, `RefineryReturnController`,
`RefineryReportController`, `Remake*Controller`, `RuffWorkController`.

### Accounting (double-entry core)
`AccountMasterController`, `AccountLedgerController`, `AccountEditEntryController`,
`AccountRestartDateController`, `ChartOfAccountsController`, `JournalController`,
`JournalReportController`, `ReceiptController`, `PaymentController`,
`PaymentConfirmationController`, `DebitCreditNoteController`, `CashBookController`,
`BankBookController`, `CashBalanceController`, `CashFlowReportController`,
`DayBookController`, `DaySummaryController`, `DailyStatementController`,
`FinancialStatementController`, `GroupLedgerController`, `GroupAccountSummaryController`,
`GroupAmtAllocationController`, `AcReceivablePayableSummaryController`,
`AcSummaryController`, `Suspense*Controller`, `RateDiffAdjustmentController`,
`ExpenseVoucherEntryController`, `AmtWgtTransferController`, `WgtRcptPmntController`,
`YearEndAccountCloseController`, `YearlyCashBalanceController`.

### Inventory / Barcode
`StockController`, `StockRegisterController`, `StockVerificationController`,
`StockSummaryCostWiseController`, `StockSummaryRateWiseController`,
`StockPeriodLedgerController`, `StockSuspenseEntryController`,
`ItemAdjustmentController`, `ItemMovementController`, `ItemwiseProfitController`,
`Barcode*Controller` (Entry, MultiEntry, History, List, Register, Settings,
StockList, StockVerify, ProfitReport, SamtList, Comparison),
`DiamondStoneStockController`, `ReorderController`, `MarkedListController`.

### Schemes / Goldsmith / Staff
`KuriDetailsController`, `KuriCollectionController`, `KuriFinishController`,
`KuriIntPostController`, `KuriTypeMasterController`, `GoldLoanController`,
`DepositReportController`, `DepositorsIntPostController`, `PdcCollectionController`,
`PdcReportController`, `Smith*Controller` (Book, List, Ageing, Lot, FixUnfix,
TransSummary, WaAnalysis, WaSummary), `GoldsmithTransaction(s)Controller`,
`GoldsmithNewWorkNoteController`, `Staff*Controller` (LeaveEntry, LogUpdate,
Payroll, Reports, Transaction, WgtTransaction), `PassbookPrintController`.

### Compliance / Integration / Reports
`EInvoiceRegisterController`, `GstrReportController`, `TallyExportController`,
`TdsReportController`, `OutstandingTaxReportController`, `PurityTestingController`,
`PurityCertificateController`, `RateController`, `GoldRateStoryController`,
`WhatsAppGatewayController`, `OwnerAppApiController`, `SaasTenantAdminController`,
`AiInsightsController`, plus the large register/summary report family.

## Supporting domain-logic docs (read before migrating any module)

- `docs/accounting-posting-logic.md` — double-entry posting rules
- `docs/transaction-create-posting-logic.txt`
- `docs/item-create-logic.txt`
- `docs/customer-supplier-staff-create-logic.txt`
- `docs/barcode-single-entry.md`
